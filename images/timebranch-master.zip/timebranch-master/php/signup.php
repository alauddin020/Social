<?php
include('class.php');
$q->complete_signup();
?>